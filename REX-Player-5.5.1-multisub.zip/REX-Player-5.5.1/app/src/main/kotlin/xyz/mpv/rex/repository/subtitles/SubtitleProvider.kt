package xyz.mpv.rex.repository.subtitles

import android.util.Log
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonElement
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.booleanOrNull
import kotlinx.serialization.json.contentOrNull
import kotlinx.serialization.json.intOrNull
import kotlinx.serialization.json.longOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import xyz.mpv.rex.repository.wyzie.WyzieErrorKind
import xyz.mpv.rex.repository.wyzie.WyzieException
import xyz.mpv.rex.repository.wyzie.WyzieLanguages
import xyz.mpv.rex.repository.wyzie.WyzieSubtitle
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.ConnectException
import java.net.SocketException
import java.net.SocketTimeoutException
import java.net.UnknownHostException
import java.util.zip.ZipInputStream
import javax.net.ssl.SSLException

private const val TAG = "SubtitleProvider"

/** Identifies the app to providers that require a recognisable User-Agent (OpenSubtitles). */
internal const val PROVIDER_USER_AGENT = "REXPlayer v1.0"

/**
 * What the user is looking for, already normalised by [SubtitleSearchRepository].
 * Providers translate this into their own request format.
 */
internal data class SubtitleQuery(
  val title: String,
  val imdbId: String?,
  val season: Int?,
  val episode: Int?,
  val year: String?,
  /** Lower-case ISO codes (e.g. "en", "id"). Empty means "any language". */
  val languages: List<String>,
  val hearingImpaired: Boolean,
) {
  val isEpisode: Boolean get() = season != null || episode != null
}

/** A subtitle file ready to be written to disk. */
internal class DownloadedSubtitle(
  val bytes: ByteArray,
  val extension: String,
)

/**
 * One online subtitle database. Add a new database by implementing this interface and
 * registering it in [SubtitleSearchRepository]; nothing else in the app needs to change.
 */
internal interface SubtitleProvider {
  val id: String
  val displayName: String

  /** True when the user has entered the credentials this provider needs. */
  fun isConfigured(): Boolean

  suspend fun search(query: SubtitleQuery): List<WyzieSubtitle>

  suspend fun download(subtitle: WyzieSubtitle): DownloadedSubtitle
}

// ==================== Shared helpers ====================

/** Maps transport failures onto [WyzieErrorKind.NetworkError] instead of reporting them as server errors. */
internal inline fun <T> mapNetworkErrors(provider: String, block: () -> T): T =
  try {
    block()
  } catch (e: WyzieException) {
    throw e
  } catch (e: SocketTimeoutException) {
    throw WyzieException(WyzieErrorKind.NetworkError, "$provider timed out", e)
  } catch (e: UnknownHostException) {
    throw WyzieException(WyzieErrorKind.NetworkError, "No connection to $provider", e)
  } catch (e: ConnectException) {
    throw WyzieException(WyzieErrorKind.NetworkError, "Could not reach $provider", e)
  } catch (e: SocketException) {
    throw WyzieException(WyzieErrorKind.NetworkError, "Could not reach $provider", e)
  } catch (e: SSLException) {
    throw WyzieException(WyzieErrorKind.NetworkError, "Secure connection to $provider failed", e)
  }

/** Turns a non-success HTTP status into a typed [WyzieException]. */
internal fun httpFailure(provider: String, code: Int, body: String): WyzieException {
  Log.e(TAG, "HTTP $code from $provider: ${body.take(300)}")
  return when (code) {
    401, 403 -> WyzieException(WyzieErrorKind.InvalidApiKey, "$provider: HTTP $code, API key or login rejected")
    429 -> WyzieException(WyzieErrorKind.RateLimited, "$provider: rate limit reached")
    in 500..599 -> WyzieException(WyzieErrorKind.ServerError, "$provider: HTTP $code, server error")
    else -> WyzieException(WyzieErrorKind.ServerError, "$provider: HTTP $code")
  }
}

/** Blocking download of a file; call from a background dispatcher. */
internal fun fetchBytes(client: OkHttpClient, request: Request, provider: String): ByteArray =
  client.newCall(request).execute().use { response ->
    if (!response.isSuccessful) {
      throw httpFailure(provider, response.code, response.body?.string().orEmpty())
    }
    val bytes = response.body?.bytes()
    if (bytes == null || bytes.isEmpty()) {
      throw WyzieException(WyzieErrorKind.ServerError, "$provider: empty subtitle file")
    }
    bytes
  }

internal fun JsonElement?.asObject(): JsonObject? = this as? JsonObject

internal fun JsonElement?.asArray(): JsonArray? = this as? JsonArray

internal fun JsonElement?.asText(): String? =
  (this as? JsonPrimitive)?.contentOrNull?.takeIf { it.isNotBlank() }

internal fun JsonElement?.asInt(): Int? = (this as? JsonPrimitive)?.intOrNull

internal fun JsonElement?.asLong(): Long? = (this as? JsonPrimitive)?.longOrNull

internal fun JsonElement?.asBool(): Boolean? = (this as? JsonPrimitive)?.booleanOrNull

/** True for the "nothing matched" messages providers return in an error field instead of an empty list. */
internal fun looksLikeNotFound(message: String): Boolean {
  val lower = message.lowercase()
  return "not found" in lower || "can't find" in lower || "cannot find" in lower ||
    "no subtitle" in lower || "no result" in lower
}

/** Hosts a provider is allowed to download from; the link is never followed blindly. */
internal fun isHostOrSubdomain(url: String, domain: String): Boolean {
  val host = runCatching { java.net.URI(url).host }.getOrNull()?.lowercase() ?: return false
  return host == domain || host.endsWith(".$domain")
}

// ==================== Languages ====================

internal object SubtitleLanguages {
  private val aliases = mapOf(
    "farsi persian" to "fa",
    "farsi" to "fa",
    "brazilian portuguese" to "pt",
    "chinese simplified" to "zh",
    "chinese traditional" to "zh",
    "chinese bg code" to "zh",
  )

  private val nameToCode: Map<String, String> by lazy {
    WyzieLanguages.ALL.entries.associate { it.value.lowercase() to it.key }
  }

  /** Accepts "en", "pt-BR", "english", "farsi_persian" and returns our ISO code, or null if unknown. */
  fun codeFor(raw: String?): String? {
    val value = raw?.trim()?.lowercase()?.takeIf { it.isNotEmpty() } ?: return null
    if (WyzieLanguages.ALL.containsKey(value)) return value
    val prefix = value.substringBefore('-').substringBefore('_')
    if (prefix.length in 2..3 && WyzieLanguages.ALL.containsKey(prefix)) return prefix
    val name = value.replace('_', ' ').replace('-', ' ')
    return aliases[name] ?: nameToCode[name]
  }

  fun displayFor(code: String?, raw: String?): String =
    code?.let { WyzieLanguages.ALL[it] }
      ?: raw?.replace('_', ' ')?.split(' ')?.joinToString(" ") { part ->
        part.replaceFirstChar { c -> c.uppercase() }
      }
      ?: "Unknown"

  /** SubSource filters by language name (lower-case, underscores), and wants one per request. */
  fun subSourceNames(code: String): List<String> = when (code) {
    "fa" -> listOf("farsi_persian")
    "zh" -> listOf("chinese_simplified", "chinese_traditional")
    "pt" -> listOf("portuguese", "brazilian_portuguese")
    else -> listOfNotNull(WyzieLanguages.ALL[code]?.lowercase()?.replace(' ', '_'))
  }
}

// ==================== Archives ====================

/**
 * SubDL and SubSource deliver ZIP archives, sometimes a whole season. This picks the one
 * subtitle file the user actually asked for, and never touches the file system: entry names
 * are only inspected, never used as paths.
 */
internal object SubtitleArchive {
  private const val MAX_ENTRY_BYTES = 8 * 1024 * 1024
  private const val MAX_ENTRIES = 500
  private val EXTENSIONS = listOf("srt", "ass", "ssa", "vtt", "sub")

  fun isZip(bytes: ByteArray): Boolean =
    bytes.size >= 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte()

  fun extract(
    bytes: ByteArray,
    season: Int?,
    episode: Int?,
    fallbackExtension: String = "srt",
  ): DownloadedSubtitle {
    if (!isZip(bytes)) return DownloadedSubtitle(bytes, fallbackExtension)

    val candidates = mutableListOf<Pair<String, ByteArray>>()
    ZipInputStream(ByteArrayInputStream(bytes)).use { zip ->
      var seen = 0
      while (true) {
        val entry = zip.nextEntry ?: break
        seen++
        if (seen > MAX_ENTRIES) break
        if (entry.isDirectory) continue
        val name = entry.name.substringAfterLast('/').substringAfterLast('\\')
        if (name.startsWith(".") || entry.name.contains("__MACOSX")) continue
        if (extensionOf(name) !in EXTENSIONS) continue
        val data = readLimited(zip) ?: continue
        candidates.add(name to data)
      }
    }

    if (candidates.isEmpty()) {
      throw WyzieException(WyzieErrorKind.ServerError, "The subtitle archive contains no subtitle file")
    }

    // A season pack holds many episodes. Picking the wrong one would give a subtitle that is
    // out of sync, so an unmatched episode is reported instead of guessed.
    val pool = if (episode != null && candidates.size > 1) {
      val matched = candidates.filter { matchesEpisode(it.first, season, episode) }
      if (matched.isEmpty()) {
        throw WyzieException(WyzieErrorKind.ServerError, "Episode $episode was not found in this subtitle pack")
      }
      matched
    } else {
      candidates
    }

    val best = pool.sortedWith(
      compareBy<Pair<String, ByteArray>>(
        { EXTENSIONS.indexOf(extensionOf(it.first)) },
        { it.first.lowercase() },
      ),
    ).first()
    return DownloadedSubtitle(best.second, extensionOf(best.first))
  }

  internal fun matchesEpisode(name: String, season: Int?, episode: Int): Boolean {
    val lower = name.lowercase()
    val patterns = mutableListOf<Regex>()
    if (season != null) {
      patterns.add(Regex("""s0*$season[ ._-]*e0*$episode(?!\d)"""))
      patterns.add(Regex("""(?<!\d)0*${season}x0*$episode(?!\d)"""))
    }
    patterns.add(Regex("""(?<![a-z0-9])(?:e|ep|episode)[ ._-]*0*$episode(?!\d)"""))
    return patterns.any { it.containsMatchIn(lower) }
  }

  private fun extensionOf(name: String): String = name.substringAfterLast('.', "").lowercase()

  private fun readLimited(input: InputStream): ByteArray? {
    val out = ByteArrayOutputStream()
    val buffer = ByteArray(8192)
    var total = 0
    while (true) {
      val read = input.read(buffer)
      if (read < 0) break
      total += read
      if (total > MAX_ENTRY_BYTES) return null
      out.write(buffer, 0, read)
    }
    return out.toByteArray()
  }
}
