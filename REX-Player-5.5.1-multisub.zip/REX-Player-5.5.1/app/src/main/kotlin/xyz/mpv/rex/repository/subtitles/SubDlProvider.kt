package xyz.mpv.rex.repository.subtitles

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import xyz.mpv.rex.preferences.SubtitlesPreferences
import xyz.mpv.rex.repository.wyzie.WyzieErrorKind
import xyz.mpv.rex.repository.wyzie.WyzieException
import xyz.mpv.rex.repository.wyzie.WyzieSubtitle
import java.io.IOException

/**
 * SubDL (subdl.com). Needs only an API key; the key goes in the query string as the API
 * requires, so request URLs are never logged here.
 */
internal class SubDlProvider(
  private val client: OkHttpClient,
  private val json: Json,
  private val preferences: SubtitlesPreferences,
) : SubtitleProvider {
  override val id = "subdl"
  override val displayName = "SubDL"

  private val searchUrl = "https://api.subdl.com/api/v1/subtitles"
  private val downloadBase = "https://dl.subdl.com"

  override fun isConfigured(): Boolean = preferences.subdlApiKey.get().isNotBlank()

  override suspend fun search(query: SubtitleQuery): List<WyzieSubtitle> = withContext(Dispatchers.IO) {
    val key = preferences.subdlApiKey.get().trim()
    if (key.isBlank()) {
      throw WyzieException(WyzieErrorKind.MissingApiKey, "SubDL API key is missing")
    }

    // A bare title does not say whether it is a series, so try movies first and then TV.
    val types = if (query.isEpisode) listOf("tv") else listOf("movie", "tv")
    for (type in types) {
      val found = mapNetworkErrors(displayName) { fetch(key, type, query) }
      if (found.isNotEmpty()) return@withContext found
    }
    emptyList()
  }

  private fun fetch(key: String, type: String, query: SubtitleQuery): List<WyzieSubtitle> {
    val url = searchUrl.toHttpUrlOrNull()?.newBuilder()?.apply {
      addQueryParameter("api_key", key)
      if (query.imdbId != null) {
        addQueryParameter("imdb_id", query.imdbId)
      } else {
        addQueryParameter("film_name", query.title)
      }
      addQueryParameter("type", type)
      query.season?.let { addQueryParameter("season_number", it.toString()) }
      query.episode?.let { addQueryParameter("episode_number", it.toString()) }
      if (query.languages.isNotEmpty()) {
        addQueryParameter("languages", query.languages.joinToString(",") { it.uppercase() })
      }
      // A series' year is its first air year, which says nothing about a given episode.
      if (type == "movie") query.year?.let { addQueryParameter("year", it) }
      addQueryParameter("subs_per_page", "30")
      if (query.hearingImpaired) addQueryParameter("hi", "1")
    }?.build() ?: throw IOException("Invalid SubDL URL")

    val request = Request.Builder().url(url).header("Accept", "application/json").build()
    return client.newCall(request).execute().use { response ->
      val body = response.body?.string().orEmpty()
      if (!response.isSuccessful) {
        if (response.code in 400..499 && looksLikeNotFound(body)) return@use emptyList()
        throw httpFailure(displayName, response.code, body)
      }
      parse(body, query)
    }
  }

  private fun parse(body: String, query: SubtitleQuery): List<WyzieSubtitle> {
    val root = try {
      json.parseToJsonElement(body).asObject()
    } catch (e: Exception) {
      null
    } ?: throw WyzieException(WyzieErrorKind.ServerError, "SubDL: unexpected response")

    if (root["status"].asBool() == false) {
      val error = root["error"].asText().orEmpty()
      val lower = error.lowercase()
      return when {
        looksLikeNotFound(error) -> emptyList()
        "api" in lower && "key" in lower ->
          throw WyzieException(WyzieErrorKind.InvalidApiKey, "SubDL: $error")
        "limit" in lower || "too many" in lower ->
          throw WyzieException(WyzieErrorKind.RateLimited, "SubDL: $error")
        else ->
          throw WyzieException(WyzieErrorKind.ServerError, "SubDL: ${error.ifBlank { "request failed" }}")
      }
    }

    val subtitles = root["subtitles"].asArray() ?: return emptyList()
    return subtitles.mapNotNull { element -> element.asObject()?.let { toSubtitle(it, query) } }
  }

  private fun toSubtitle(item: JsonObject, query: SubtitleQuery): WyzieSubtitle? {
    val link = resolveDownloadUrl(item["download_link"].asText(), item["url"].asText()) ?: return null

    // Searches can return neighbouring episodes; 0 means a whole-season pack, which is kept.
    val itemSeason = item["season"].asInt() ?: 0
    val itemEpisode = item["episode"].asInt() ?: 0
    if (query.season != null && itemSeason > 0 && itemSeason != query.season) return null
    if (query.episode != null && itemEpisode > 0 && itemEpisode != query.episode) return null

    val isHearingImpaired = item["hi"].asBool()
    if (query.hearingImpaired && isHearingImpaired == false) return null

    val rawLanguage = item["language"].asText() ?: item["lang"].asText()
    val code = SubtitleLanguages.codeFor(rawLanguage) ?: SubtitleLanguages.codeFor(item["lang"].asText())

    return WyzieSubtitle(
      id = item["subtitle_id"].asText() ?: link.substringAfterLast('/').substringBefore('.'),
      url = link,
      display = SubtitleLanguages.displayFor(code, item["lang"].asText() ?: rawLanguage),
      language = code ?: rawLanguage?.lowercase(),
      isHearingImpaired = isHearingImpaired == true,
      source = displayName,
      release = item["release_name"].asText() ?: item["name"].asText(),
      providerId = id,
      providerRef = link,
      season = query.season,
      episode = query.episode,
    )
  }

  private fun resolveDownloadUrl(link: String?, path: String?): String? {
    val candidate = when {
      link != null && link.startsWith("https://") -> link
      path != null && path.startsWith("https://") -> path
      path != null -> downloadBase + (if (path.startsWith("/")) path else "/$path")
      else -> return null
    }
    return candidate.takeIf { isHostOrSubdomain(it, "subdl.com") }
  }

  override suspend fun download(subtitle: WyzieSubtitle): DownloadedSubtitle = withContext(Dispatchers.IO) {
    val link = subtitle.providerRef ?: subtitle.url
    if (!isHostOrSubdomain(link, "subdl.com")) {
      throw WyzieException(WyzieErrorKind.ServerError, "SubDL: unexpected download address")
    }
    val bytes = mapNetworkErrors(displayName) {
      fetchBytes(client, Request.Builder().url(link).build(), displayName)
    }
    SubtitleArchive.extract(bytes, subtitle.season, subtitle.episode)
  }
}
