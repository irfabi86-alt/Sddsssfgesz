package xyz.mpv.rex.repository.subtitles

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonArray
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import kotlinx.serialization.json.contentOrNull
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import xyz.mpv.rex.preferences.SubtitlesPreferences
import xyz.mpv.rex.repository.wyzie.WyzieErrorKind
import xyz.mpv.rex.repository.wyzie.WyzieException
import xyz.mpv.rex.repository.wyzie.WyzieSubtitle
import java.io.IOException

/**
 * SubSource (subsource.net). Free API key from the profile page, sent as `X-API-Key`.
 *
 * SubSource does not search by title directly: the title is first resolved to a movie id,
 * then subtitles are listed per language for that id.
 */
internal class SubSourceProvider(
  private val client: OkHttpClient,
  private val json: Json,
  private val preferences: SubtitlesPreferences,
) : SubtitleProvider {
  override val id = "subsource"
  override val displayName = "SubSource"

  private val base = "https://api.subsource.net/api/v1"

  override fun isConfigured(): Boolean = preferences.subsourceApiKey.get().isNotBlank()

  override suspend fun search(query: SubtitleQuery): List<WyzieSubtitle> = withContext(Dispatchers.IO) {
    val key = preferences.subsourceApiKey.get().trim()
    if (key.isBlank()) {
      throw WyzieException(WyzieErrorKind.MissingApiKey, "SubSource API key is missing")
    }

    val movieId = mapNetworkErrors(displayName) { resolveMovieId(key, query) }
      ?: return@withContext emptyList()

    // The API takes one language per request. Cap the fan-out to stay polite with the quota.
    val languageNames = query.languages.flatMap { SubtitleLanguages.subSourceNames(it) }.distinct().take(5)
    val languageParams: List<String?> = if (languageNames.isEmpty()) listOf<String?>(null) else languageNames

    // One language failing (for example a name SubSource does not know) must not hide the
    // others: only report an error when every language failed.
    val outcomes = coroutineScope {
      languageParams.map { language ->
        async {
          try {
            Result.success(mapNetworkErrors(displayName) { fetchSubtitles(key, movieId, language, query) })
          } catch (e: CancellationException) {
            throw e
          } catch (e: Exception) {
            Result.failure<List<WyzieSubtitle>>(e)
          }
        }
      }.awaitAll()
    }
    val succeeded = outcomes.mapNotNull { it.getOrNull() }
    if (succeeded.isEmpty()) {
      outcomes.firstNotNullOfOrNull { it.exceptionOrNull() }?.let { throw it }
    }
    succeeded.flatten()
  }

  // ==================== Title -> movie id ====================

  private class Candidate(
    val movieId: Long,
    val score: Int,
  )

  private fun resolveMovieId(key: String, query: SubtitleQuery): Long? {
    val url = "$base/movies/search".toHttpUrlOrNull()?.newBuilder()?.apply {
      if (query.imdbId != null) {
        addQueryParameter("searchType", "imdb")
        addQueryParameter("imdb", query.imdbId)
      } else {
        addQueryParameter("searchType", "text")
        addQueryParameter("q", query.title)
      }
      if (query.isEpisode) query.season?.let { addQueryParameter("season", it.toString()) }
    }?.build() ?: throw IOException("Invalid SubSource URL")

    val body = client.newCall(authorized(url.toString(), key)).execute().use { response ->
      val text = response.body?.string().orEmpty()
      if (response.code == 404) return@use null
      if (!response.isSuccessful) throw httpFailure(displayName, response.code, text)
      text
    } ?: return null

    val data = parseObject(body).get("data").asArray() ?: return null
    val wantedTitle = query.title.lowercase().trim()
    val wantedSeason = query.season

    val candidates = data.mapIndexedNotNull { index, element ->
      val movie = element.asObject() ?: return@mapIndexedNotNull null
      val movieId = movie["movieId"].asLong() ?: return@mapIndexedNotNull null
      val title = movie["title"].asText()?.lowercase()?.trim().orEmpty()
      val alternate = movie["alternateTitle"].asText()?.lowercase()?.trim().orEmpty()
      val type = movie["type"].asText().orEmpty()
      val isSeries = type.equals("series", ignoreCase = true) || type.equals("tv", ignoreCase = true)

      var score = 100 - index
      if (title == wantedTitle || alternate == wantedTitle) {
        score += 1000
      } else if (wantedTitle.isNotEmpty() && (title.contains(wantedTitle) || alternate.contains(wantedTitle))) {
        score += 300
      }
      if (query.year != null && movie["releaseYear"].asInt()?.toString() == query.year) score += 500
      if (query.isEpisode) {
        if (isSeries) score += 300
        if (wantedSeason != null && movie["season"].asInt() == wantedSeason) score += 400
      } else if (!isSeries) {
        score += 300
      }
      Candidate(movieId, score)
    }
    return candidates.maxByOrNull { it.score }?.movieId
  }

  // ==================== Subtitles ====================

  private fun fetchSubtitles(
    key: String,
    movieId: Long,
    language: String?,
    query: SubtitleQuery,
  ): List<WyzieSubtitle> {
    val url = "$base/subtitles".toHttpUrlOrNull()?.newBuilder()?.apply {
      addQueryParameter("movieId", movieId.toString())
      language?.let { addQueryParameter("language", it) }
      addQueryParameter("limit", "100")
      addQueryParameter("sort", "rating")
      if (query.hearingImpaired) addQueryParameter("hearingImpaired", "true")
    }?.build() ?: throw IOException("Invalid SubSource URL")

    val body = client.newCall(authorized(url.toString(), key)).execute().use { response ->
      val text = response.body?.string().orEmpty()
      if (response.code == 404) return@use null
      if (!response.isSuccessful) throw httpFailure(displayName, response.code, text)
      text
    } ?: return emptyList()

    val data = parseObject(body).get("data").asArray() ?: return emptyList()
    return data.mapNotNull { element -> element.asObject()?.let { toSubtitle(it, query) } }
  }

  private fun toSubtitle(item: JsonObject, query: SubtitleQuery): WyzieSubtitle? {
    val subtitleId = item["subtitleId"].asLong() ?: return null
    val releases = when (val info = item["releaseInfo"]) {
      is JsonArray -> info.mapNotNull { it.asText() }
      is JsonPrimitive -> listOfNotNull(info.contentOrNull?.takeIf { it.isNotBlank() })
      else -> emptyList()
    }
    if (query.isEpisode && namesAnotherEpisode(releases, query.season, query.episode)) return null

    val rawLanguage = item["language"].asText()
    val code = SubtitleLanguages.codeFor(rawLanguage)

    return WyzieSubtitle(
      id = subtitleId.toString(),
      url = "$base/subtitles/$subtitleId/download",
      display = SubtitleLanguages.displayFor(code, rawLanguage),
      language = code ?: rawLanguage?.lowercase(),
      isHearingImpaired = item["hearingImpaired"].asBool() == true,
      source = displayName,
      release = releases.firstOrNull(),
      releases = releases,
      downloadCount = item["downloads"].asInt(),
      providerId = id,
      providerRef = subtitleId.toString(),
      season = query.season,
      episode = query.episode,
    )
  }

  /**
   * True when a release name clearly belongs to a different episode (S01E03 while looking for
   * S01E02). Names without an episode marker are kept: they are usually season packs.
   */
  private fun namesAnotherEpisode(releases: List<String>, season: Int?, episode: Int?): Boolean {
    if (episode == null) return false
    val marker = Regex("""s(\d{1,2})[ ._-]*e(\d{1,3})""", RegexOption.IGNORE_CASE)
    val markers = releases.mapNotNull { marker.find(it) }
    if (markers.isEmpty()) return false
    return markers.none { match ->
      val foundSeason = match.groupValues[1].toIntOrNull()
      val foundEpisode = match.groupValues[2].toIntOrNull()
      foundEpisode == episode && (season == null || foundSeason == season)
    }
  }

  // ==================== Download ====================

  override suspend fun download(subtitle: WyzieSubtitle): DownloadedSubtitle = withContext(Dispatchers.IO) {
    val subtitleId = subtitle.providerRef?.toLongOrNull()
      ?: throw WyzieException(WyzieErrorKind.ServerError, "SubSource: missing subtitle id")
    val key = preferences.subsourceApiKey.get().trim()
    if (key.isBlank()) {
      throw WyzieException(WyzieErrorKind.MissingApiKey, "SubSource API key is missing")
    }
    val bytes = mapNetworkErrors(displayName) {
      fetchBytes(client, authorized("$base/subtitles/$subtitleId/download", key), displayName)
    }
    SubtitleArchive.extract(bytes, subtitle.season, subtitle.episode)
  }

  // ==================== Helpers ====================

  private fun authorized(url: String, key: String): Request =
    Request.Builder()
      .url(url)
      .header("X-API-Key", key)
      .header("Accept", "application/json")
      .build()

  private fun parseObject(body: String): JsonObject =
    try {
      json.parseToJsonElement(body).asObject()
    } catch (e: Exception) {
      null
    } ?: throw WyzieException(WyzieErrorKind.ServerError, "SubSource: unexpected response")
}
