package xyz.mpv.rex.ui.browser.shorts

import android.util.Xml
import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import xyz.mpv.rex.R
import xyz.mpv.rex.ui.player.MPVLifecycleLock
import xyz.mpv.rex.ui.player.MPVView
import xyz.mpv.rex.ui.player.MpvConfigSync
import `is`.xyz.mpv.MPVLib
import `is`.xyz.mpv.MPVNode
import org.xmlpull.v1.XmlPullParser

@Composable
fun ShortsPlayerHost(
    modifier: Modifier = Modifier,
    onReady: (MPVView) -> Unit,
    onPlayerReadyChange: (Boolean) -> Unit,
    onProgressUpdate: (timePos: Double, duration: Long) -> Unit = { _, _ -> },
    onPauseUpdate: (Boolean) -> Unit = {},
    onPlaybackEnd: () -> Unit = {}
) {
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    val mpvView = remember {
        val parser = context.resources.getLayout(R.layout.shorts_dummy_layout)
        var type: Int
        while (parser.next().also { type = it } != XmlPullParser.START_TAG && type != XmlPullParser.END_DOCUMENT) {
        }
        val attrs = Xml.asAttributeSet(parser)
        
        MPVView(context, attrs).apply {
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }
    }

    DisposableEffect(Unit) {
        var fileLoadedJob: Job? = null
        val observer = object : MPVLib.EventObserver {
            private var lastTimePos = 0.0
            private var lastDuration = 0L

            override fun event(eventId: Int, data: MPVNode) {
                when (eventId) {
                    MPVLib.MpvEvent.MPV_EVENT_START_FILE -> {
                        fileLoadedJob?.cancel()
                        fileLoadedJob = null
                        onPlayerReadyChange(false)
                        lastTimePos = 0.0
                        lastDuration = 0L
                        onProgressUpdate(0.0, 0L)
                    }
                    MPVLib.MpvEvent.MPV_EVENT_FILE_LOADED -> {
                        fileLoadedJob?.cancel()
                        fileLoadedJob = coroutineScope.launch {
                            delay(150)
                            onPlayerReadyChange(true)
                        }
                    }
                }
            }
            override fun eventProperty(property: String) {}
            override fun eventProperty(property: String, value: Long) {
                if (property == "duration") {
                    lastDuration = value
                    onProgressUpdate(lastTimePos, lastDuration)
                }
            }
            override fun eventProperty(property: String, value: Boolean) {
                when (property) {
                    "pause" -> onPauseUpdate(value)
                    "eof-reached" -> {
                        if (value) {
                            onPlaybackEnd()
                        }
                    }
                }
            }
            override fun eventProperty(property: String, value: String) {}
            override fun eventProperty(property: String, value: Double) {
                if (property == "time-pos") {
                    lastTimePos = value
                    onProgressUpdate(lastTimePos, lastDuration)
                }
            }
            override fun eventProperty(property: String, value: MPVNode) {}
        }

        if (MPVLifecycleLock.isTearingDown.value) {
            runBlocking(Dispatchers.IO) {
                MPVLifecycleLock.awaitTeardown()
            }
        }
        MpvConfigSync.prepare(context)

        mpvView.initialize(context.filesDir.path, context.cacheDir.path)
        MPVLib.setPropertyString("loop-file", "inf")
        MPVLib.observeProperty("time-pos", MPVLib.MpvFormat.MPV_FORMAT_DOUBLE)
        MPVLib.observeProperty("duration", MPVLib.MpvFormat.MPV_FORMAT_INT64)
        MPVLib.addObserver(observer)
        onReady(mpvView)
        
        onDispose {
            fileLoadedJob?.cancel()
            fileLoadedJob = null
            MPVLib.removeObserver(observer)
            MPVLifecycleLock.onTeardownStart()
            try {
                mpvView.destroy()
            } finally {
                MPVLifecycleLock.onTeardownComplete()
            }
        }
    }

    AndroidView(
        factory = {
            FrameLayout(context).apply {
                (mpvView.parent as? ViewGroup)?.removeView(mpvView)
                addView(mpvView)
            }
        },
        modifier = modifier
    )
}
