package xyz.mpv.rex.di

import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import xyz.mpv.rex.database.MpvExDatabase
import xyz.mpv.rex.database.repository.BookmarkRepositoryImpl
import xyz.mpv.rex.database.repository.MediaPlayCountRepository
import xyz.mpv.rex.database.repository.PlaybackStateRepositoryImpl
import xyz.mpv.rex.database.repository.PlaylistRepository
import xyz.mpv.rex.database.repository.RecentlyPlayedRepositoryImpl
import xyz.mpv.rex.domain.playbackstate.repository.PlaybackStateRepository
import xyz.mpv.rex.domain.bookmark.repository.BookmarkRepository
import xyz.mpv.rex.domain.recentlyplayed.repository.RecentlyPlayedRepository
import xyz.mpv.rex.domain.thumbnail.ThumbnailRepository
import xyz.mpv.rex.utils.storage.FolderAggregateRepository
import xyz.mpv.rex.utils.storage.FolderAggregateSource
import xyz.mpv.rex.utils.storage.MediaTreeStore
import kotlinx.serialization.json.Json
import org.koin.android.ext.koin.androidContext
import org.koin.core.module.dsl.singleOf
import org.koin.dsl.bind
import org.koin.dsl.module

/**
 * Migration from version 1 (v1.0.0) to version 2 (v1.1.0)
 *
 * This is a squashed migration that handles ALL schema changes between v1.0.0 and v1.1.0
 *
 * Version 1 (v1.0.0) had 3 tables:
 * - PlaybackStateEntity (with secondarySid and secondarySubDelay columns, no videoZoom)
 * - RecentlyPlayedEntity (with columns: id, filePath, fileName, timestamp, launchSource)
 * - ExternalSubtitleEntity
 *
 * Version 2 (v1.1.0) changes:
 * - PlaybackStateEntity: Removes secondarySid and secondarySubDelay, adds videoZoom
 * - Removes ExternalSubtitleEntity table
 * - Adds video_metadata_cache table (for MediaInfo caching)
 * - Adds network_connections table (for SMB/FTP/WebDAV)
 * - Adds PlaylistEntity table (for custom playlists)
 * - Adds PlaylistItemEntity table (playlist items with foreign key)
 * - Adds 6 new columns to RecentlyPlayedEntity (videoTitle, duration, fileSize, width, height, playlistId)
 */
val MIGRATION_1_2 = object : Migration(1, 2) {
  override fun migrate(db: SupportSQLiteDatabase) {
    try {
      android.util.Log.d("Migration_1_2", "Starting migration from v1.0.0 to v1.1.0")

      // ===== 1. Update PlaybackStateEntity: Remove secondarySid/secondarySubDelay, add videoZoom =====
      android.util.Log.d("Migration_1_2", "Updating PlaybackStateEntity schema")

      // Create new PlaybackStateEntity table with correct schema
      db.execSQL(
        """
        CREATE TABLE IF NOT EXISTS `PlaybackStateEntity_new` (
          `mediaTitle` TEXT NOT NULL,
          `lastPosition` INTEGER NOT NULL,
          `playbackSpeed` REAL NOT NULL,
          `videoZoom` REAL NOT NULL DEFAULT 0.0,
          `sid` INTEGER NOT NULL,
          `subDelay` INTEGER NOT NULL,
          `subSpeed` REAL NOT NULL,
          `aid` INTEGER NOT NULL,
          `audioDelay` INTEGER NOT NULL,
          `timeRemaining` INTEGER NOT NULL DEFAULT 0,
          PRIMARY KEY(`mediaTitle`)
        )
        """.trimIndent(),
      )

      // Copy data from old table (excluding secondarySid and secondarySubDelay, adding videoZoom with default)
      db.execSQL(
        """
        INSERT INTO `PlaybackStateEntity_new` 
        (`mediaTitle`, `lastPosition`, `playbackSpeed`, `videoZoom`, `sid`, `subDelay`, 
         `subSpeed`, `aid`, `audioDelay`, `timeRemaining`)
        SELECT `mediaTitle`, `lastPosition`, `playbackSpeed`, 0.0, `sid`, `subDelay`, 
               `subSpeed`, `aid`, `audioDelay`, `timeRemaining`
        FROM `PlaybackStateEntity`
        """.trimIndent(),
      )

      // Drop old table and rename new one
      db.execSQL("DROP TABLE `PlaybackStateEntity`")
      db.execSQL("ALTER TABLE `PlaybackStateEntity_new` RENAME TO `PlaybackStateEntity`")

      // ===== 2. Drop ExternalSubtitleEntity table =====
      android.util.Log.d("Migration_1_2", "Removing ExternalSubtitleEntity table")
      db.execSQL("DROP TABLE IF EXISTS `ExternalSubtitleEntity`")

      // ===== 3. Create video_metadata_cache table =====
      android.util.Log.d("Migration_1_2", "Creating video_metadata_cache table")
      db.execSQL(
        """
        CREATE TABLE IF NOT EXISTS `video_metadata_cache` (
          `path` TEXT NOT NULL,
          `size` INTEGER NOT NULL,
          `dateModified` INTEGER NOT NULL,
          `duration` INTEGER NOT NULL,
          `width` INTEGER NOT NULL,
          `height` INTEGER NOT NULL,
          `fps` REAL NOT NULL,
          `lastScanned` INTEGER NOT NULL,
          PRIMARY KEY(`path`)
        )
        """.trimIndent(),
      )

      // ===== 4. Create network_connections table =====
      android.util.Log.d("Migration_1_2", "Creating network_connections table")
      db.execSQL(
        """
        CREATE TABLE IF NOT EXISTS `network_connections` (
          `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
          `name` TEXT NOT NULL,
          `protocol` TEXT NOT NULL,
          `host` TEXT NOT NULL,
          `port` INTEGER NOT NULL,
          `username` TEXT NOT NULL DEFAULT '',
          `password` TEXT NOT NULL DEFAULT '',
          `path` TEXT NOT NULL DEFAULT '/',
          `isAnonymous` INTEGER NOT NULL DEFAULT 0,
          `lastConnected` INTEGER NOT NULL DEFAULT 0,
          `autoConnect` INTEGER NOT NULL DEFAULT 0
        )
        """.trimIndent(),
      )

      // ===== 5. Create PlaylistEntity table =====
      android.util.Log.d("Migration_1_2", "Creating PlaylistEntity table")
      db.execSQL(
        """
        CREATE TABLE IF NOT EXISTS `PlaylistEntity` (
          `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
          `name` TEXT NOT NULL,
          `createdAt` INTEGER NOT NULL,
          `updatedAt` INTEGER NOT NULL
        )
        """.trimIndent(),
      )

      // ===== 6. Create PlaylistItemEntity table with foreign key =====
      android.util.Log.d("Migration_1_2", "Creating PlaylistItemEntity table")
      db.execSQL(
        """
        CREATE TABLE IF NOT EXISTS `PlaylistItemEntity` (
          `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
          `playlistId` INTEGER NOT NULL,
          `filePath` TEXT NOT NULL,
          `fileName` TEXT NOT NULL,
          `position` INTEGER NOT NULL,
          `addedAt` INTEGER NOT NULL,
          `lastPlayedAt` INTEGER NOT NULL DEFAULT 0,
          `playCount` INTEGER NOT NULL DEFAULT 0,
          `lastPosition` INTEGER NOT NULL DEFAULT 0,
          FOREIGN KEY(`playlistId`) REFERENCES `PlaylistEntity`(`id`) ON DELETE CASCADE
        )
        """.trimIndent(),
      )

      // Create index for PlaylistItemEntity foreign key
      db.execSQL(
        "CREATE INDEX IF NOT EXISTS `index_PlaylistItemEntity_playlistId` ON `PlaylistItemEntity` (`playlistId`)",
      )

      // ===== 7. Add new columns to RecentlyPlayedEntity =====
      android.util.Log.d("Migration_1_2", "Adding columns to RecentlyPlayedEntity")
      db.execSQL("ALTER TABLE `RecentlyPlayedEntity` ADD COLUMN `videoTitle` TEXT")
      db.execSQL("ALTER TABLE `RecentlyPlayedEntity` ADD COLUMN `duration` INTEGER NOT NULL DEFAULT 0")
      db.execSQL("ALTER TABLE `RecentlyPlayedEntity` ADD COLUMN `fileSize` INTEGER NOT NULL DEFAULT 0")
      db.execSQL("ALTER TABLE `RecentlyPlayedEntity` ADD COLUMN `width` INTEGER NOT NULL DEFAULT 0")
      db.execSQL("ALTER TABLE `RecentlyPlayedEntity` ADD COLUMN `height` INTEGER NOT NULL DEFAULT 0")
      db.execSQL("ALTER TABLE `RecentlyPlayedEntity` ADD COLUMN `playlistId` INTEGER")

      android.util.Log.d("Migration_1_2", "Migration completed successfully")

    } catch (e: Exception) {
      android.util.Log.e("Migration_1_2", "Migration failed", e)
      throw e
    }
  }
}

/**
 * Migration from version 2 to version 3
 *
 * Changes:
 * - Adds externalSubtitles column to PlaybackStateEntity to persist external subtitle URIs
 */
val MIGRATION_2_3 = object : Migration(2, 3) {
  override fun migrate(db: SupportSQLiteDatabase) {
    try {
      android.util.Log.d("Migration_2_3", "Starting migration from version 2 to version 3")

      // Add externalSubtitles column to PlaybackStateEntity
      db.execSQL("ALTER TABLE `PlaybackStateEntity` ADD COLUMN `externalSubtitles` TEXT NOT NULL DEFAULT ''")

      // Add subtitleCodec column to video_metadata_cache
      db.execSQL("ALTER TABLE video_metadata_cache ADD COLUMN subtitleCodec TEXT NOT NULL DEFAULT ''")


      android.util.Log.d("Migration_2_3", "Migration completed successfully")
    } catch (e: Exception) {
      android.util.Log.e("Migration_2_3", "Migration failed", e)
      throw e
    }
  }
}

/**
 * Migration from version 3 to version 4
 *
 * Changes:
 * - Adds m3uSourceUrl and isM3uPlaylist columns to PlaylistEntity for M3U/M3U8 playlist support
 */
val MIGRATION_3_4 = object : Migration(3, 4) {
  override fun migrate(db: SupportSQLiteDatabase) {
    try {
      android.util.Log.d("Migration_3_4", "Starting migration from version 3 to version 4")

      // Add M3U-related columns to PlaylistEntity
      db.execSQL(
        "ALTER TABLE `PlaylistEntity` ADD COLUMN `m3uSourceUrl` TEXT DEFAULT NULL"
      )
      db.execSQL(
        "ALTER TABLE `PlaylistEntity` ADD COLUMN `isM3uPlaylist` INTEGER NOT NULL DEFAULT 0"
      )

      android.util.Log.d("Migration_3_4", "Migration completed successfully")
    } catch (e: Exception) {
      android.util.Log.e("Migration_3_4", "Migration failed", e)
      throw e
    }
  }
}

/**
 * Migration from version 4 to version 5
 *
 * Changes:
 * - Adds secondarySid column to PlaybackStateEntity to persist secondary subtitle track
 *   This allows saving and restoring both primary and secondary subtitle selections
 */
val MIGRATION_4_5 = object : Migration(4, 5) {
  override fun migrate(db: SupportSQLiteDatabase) {
    try {
      android.util.Log.d("Migration_4_5", "Starting migration from version 4 to version 5")

      // Add secondarySid column to PlaybackStateEntity (-1 means disabled)
      db.execSQL(
        "ALTER TABLE `PlaybackStateEntity` ADD COLUMN `secondarySid` INTEGER NOT NULL DEFAULT -1"
      )

      android.util.Log.d("Migration_4_5", "Migration completed successfully")
    } catch (e: Exception) {
      android.util.Log.e("Migration_4_5", "Migration failed", e)
      throw e
    }
  }
}

val MIGRATION_5_6 = object : Migration(5, 6) {
  override fun migrate(db: SupportSQLiteDatabase) {
    try {
      android.util.Log.d("Migration_5_6", "Starting migration from version 5 to 6")
      
      // Get existing columns to check what needs to be added
      val cursor = db.query("PRAGMA table_info(video_metadata_cache)")
      val existingColumns = mutableSetOf<String>()
      while (cursor.moveToNext()) {
        val columnName = cursor.getString(cursor.getColumnIndexOrThrow("name"))
        existingColumns.add(columnName)
      }
      cursor.close()
      
      // Add subtitleCodec if it doesn't exist yet (should have been added in MIGRATION_2_3 but might be missing)
      if (!existingColumns.contains("subtitleCodec")) {
        try {
          db.execSQL("ALTER TABLE `video_metadata_cache` ADD COLUMN `subtitleCodec` TEXT NOT NULL DEFAULT ''")
          android.util.Log.d("Migration_5_6", "Added subtitleCodec column")
        } catch (e: Exception) {
          android.util.Log.w("Migration_5_6", "Error adding subtitleCodec column, may already exist", e)
        }
      } else {
        android.util.Log.d("Migration_5_6", "subtitleCodec column already exists, skipping")
      }
      
      // Add hasEmbeddedSubtitles if it doesn't exist
      if (!existingColumns.contains("hasEmbeddedSubtitles")) {
        try {
          db.execSQL("ALTER TABLE `video_metadata_cache` ADD COLUMN `hasEmbeddedSubtitles` INTEGER NOT NULL DEFAULT 0")
          android.util.Log.d("Migration_5_6", "Added hasEmbeddedSubtitles column")
        } catch (e: Exception) {
          android.util.Log.w("Migration_5_6", "Error adding hasEmbeddedSubtitles column, may already exist", e)
        }
      } else {
        android.util.Log.d("Migration_5_6", "hasEmbeddedSubtitles column already exists, skipping")
      }
      
      android.util.Log.d("Migration_5_6", "Migration completed successfully")
    } catch (e: Exception) {
      android.util.Log.e("Migration_5_6", "Migration failed", e)
      throw e
    }
  }
}

/**
 * Migration from version 6 to version 7
 *
 * Changes:
 * - Adds useHttps column to network_connections table for explicit HTTPS control on WebDAV
 */
val MIGRATION_6_7 = object : Migration(6, 7) {
  override fun migrate(db: SupportSQLiteDatabase) {
    try {
      android.util.Log.d("Migration_6_7", "Starting migration from version 6 to 7")
      
      // Add useHttps column to network_connections table
      db.execSQL("ALTER TABLE `network_connections` ADD COLUMN `useHttps` INTEGER NOT NULL DEFAULT 0")
      
      android.util.Log.d("Migration_6_7", "Migration completed successfully")
    } catch (e: Exception) {
      android.util.Log.e("Migration_6_7", "Migration failed", e)
      throw e
    }
  }
}

/**
 * Migration from version 7 to version 8
 *
 * Changes:
 * - Adds hasBeenWatched column to PlaybackStateEntity to persist watched status
 */
val MIGRATION_7_8 = object : Migration(7, 8) {
  override fun migrate(db: SupportSQLiteDatabase) {
    try {
      android.util.Log.d("Migration_7_8", "Starting migration from version 7 to 8")
      
      // Add hasBeenWatched column to PlaybackStateEntity
      db.execSQL("ALTER TABLE `PlaybackStateEntity` ADD COLUMN `hasBeenWatched` INTEGER NOT NULL DEFAULT 0")
      
      android.util.Log.d("Migration_7_8", "Migration completed successfully")
    } catch (e: Exception) {
      android.util.Log.e("Migration_7_8", "Migration failed", e)
      throw e
    }
  }
}

/**
 * Migration from version 8 to version 9
 *
 * This is a repair migration to fix databases that have incorrect schema at version 6/7/8.
 * Some users have databases that claim to be version 6+ but still have the old v1 schema
 * with secondarySubDelay column instead of externalSubtitles.
 *
 * Changes:
 * - Ensures PlaybackStateEntity has the correct schema by recreating the table
 * - Preserves all existing data during the migration
 */
val MIGRATION_8_9 = object : Migration(8, 9) {
  override fun migrate(db: SupportSQLiteDatabase) {
    try {
      android.util.Log.d("Migration_8_9", "Starting migration from version 8 to 9 (schema repair)")
      
      // Check current schema to see if we need to repair
      val cursor = db.query("PRAGMA table_info(PlaybackStateEntity)")
      val existingColumns = mutableSetOf<String>()
      while (cursor.moveToNext()) {
        val columnName = cursor.getString(cursor.getColumnIndexOrThrow("name"))
        existingColumns.add(columnName)
      }
      cursor.close()
      
      android.util.Log.d("Migration_8_9", "Existing columns: $existingColumns")
      
      // Check if we have the wrong schema
      val hasSecondarySubDelay = existingColumns.contains("secondarySubDelay")
      val hasExternalSubtitles = existingColumns.contains("externalSubtitles")
      val hasHasBeenWatched = existingColumns.contains("hasBeenWatched")
      val hasSavedOrientation = existingColumns.contains("savedOrientation")
      
      if (hasSecondarySubDelay || !hasExternalSubtitles || !hasHasBeenWatched || !hasSavedOrientation) {
        android.util.Log.d("Migration_8_9", "Schema mismatch detected, recreating table")
        
        // Create new table with correct schema
        db.execSQL(
          """
          CREATE TABLE IF NOT EXISTS `PlaybackStateEntity_new` (
            `mediaTitle` TEXT NOT NULL,
            `lastPosition` INTEGER NOT NULL,
            `playbackSpeed` REAL NOT NULL,
            `videoZoom` REAL NOT NULL DEFAULT 0.0,
            `sid` INTEGER NOT NULL,
            `secondarySid` INTEGER NOT NULL DEFAULT -1,
            `subDelay` INTEGER NOT NULL,
            `subSpeed` REAL NOT NULL,
            `aid` INTEGER NOT NULL,
            `audioDelay` INTEGER NOT NULL,
            `timeRemaining` INTEGER NOT NULL DEFAULT 0,
            `savedOrientation` INTEGER,
            `externalSubtitles` TEXT NOT NULL DEFAULT '',
            `hasBeenWatched` INTEGER NOT NULL DEFAULT 0,
            PRIMARY KEY(`mediaTitle`)
          )
          """.trimIndent()
        )
        
        // Copy data from old table, handling missing columns
        val columns = mutableListOf("mediaTitle", "lastPosition", "playbackSpeed", "videoZoom", "sid", "secondarySid", "subDelay", "subSpeed", "aid", "audioDelay", "timeRemaining")
        val select = mutableListOf("mediaTitle", "lastPosition", "playbackSpeed", "videoZoom", "sid", "secondarySid", "subDelay", "subSpeed", "aid", "audioDelay", "timeRemaining")
        
        // Handle savedOrientation
        columns.add("savedOrientation")
        if (hasSavedOrientation) {
          select.add("savedOrientation")
        } else {
          select.add("NULL")
        }
        
        // Handle externalSubtitles
        columns.add("externalSubtitles")
        if (hasExternalSubtitles) {
          select.add("externalSubtitles")
        } else {
          select.add("''")
        }
        
        // Handle hasBeenWatched
        columns.add("hasBeenWatched")
        if (hasHasBeenWatched) {
          select.add("hasBeenWatched")
        } else {
          select.add("0")
        }
        
        val columnsStr = columns.joinToString("`, `", "`", "`")
        val selectStr = select.joinToString(", ")
        
        db.execSQL("INSERT INTO `PlaybackStateEntity_new` ($columnsStr) SELECT $selectStr FROM `PlaybackStateEntity`")
        
        // Drop old table and rename new one
        db.execSQL("DROP TABLE `PlaybackStateEntity`")
        db.execSQL("ALTER TABLE `PlaybackStateEntity_new` RENAME TO `PlaybackStateEntity`")
        
        android.util.Log.d("Migration_8_9", "Table recreated successfully")
      } else {
        android.util.Log.d("Migration_8_9", "Schema is correct, no repair needed")
      }
      
      android.util.Log.d("Migration_8_9", "Migration completed successfully")
    } catch (e: Exception) {
      android.util.Log.e("Migration_8_9", "Migration failed", e)
      throw e
    }
  }
}


val MIGRATION_9_10 = object : Migration(9, 10) {
  override fun migrate(db: SupportSQLiteDatabase) {
    db.execSQL("ALTER TABLE `video_metadata_cache` ADD COLUMN `artist` TEXT NOT NULL DEFAULT ''")
    db.execSQL("ALTER TABLE `video_metadata_cache` ADD COLUMN `album` TEXT NOT NULL DEFAULT ''")
  }
}

val MIGRATION_10_11 = object : Migration(10, 11) {
  override fun migrate(db: SupportSQLiteDatabase) {
    db.execSQL("ALTER TABLE `RecentlyPlayedEntity` ADD COLUMN `isAudio` INTEGER NOT NULL DEFAULT 0")
    db.execSQL("ALTER TABLE `RecentlyPlayedEntity` ADD COLUMN `artist` TEXT NOT NULL DEFAULT ''")
    db.execSQL("ALTER TABLE `RecentlyPlayedEntity` ADD COLUMN `album` TEXT NOT NULL DEFAULT ''")
  }
}

val MIGRATION_11_12 = object : Migration(11, 12) {
  override fun migrate(db: SupportSQLiteDatabase) {
    db.execSQL("ALTER TABLE `video_metadata_cache` ADD COLUMN `rotation` INTEGER NOT NULL DEFAULT 0")
  }
}

val MIGRATION_12_13 = object : Migration(12, 13) {
  override fun migrate(db: SupportSQLiteDatabase) {
    db.execSQL(
      """
      CREATE TABLE IF NOT EXISTS `shorts_media` (
        `path` TEXT NOT NULL,
        `isLoved` INTEGER NOT NULL DEFAULT 0,
        `isBlocked` INTEGER NOT NULL DEFAULT 0,
        `isManuallyAdded` INTEGER NOT NULL DEFAULT 0,
        `addedDate` INTEGER NOT NULL,
        PRIMARY KEY(`path`)
      )
      """.trimIndent()
    )
  }
}

val MIGRATION_13_14 = object : Migration(13, 14) {
  override fun migrate(db: SupportSQLiteDatabase) {
    db.execSQL("ALTER TABLE `PlaybackStateEntity` ADD COLUMN `externalAudioTracks` TEXT NOT NULL DEFAULT ''")
  }
}

val MIGRATION_14_15 = object : Migration(14, 15) {
  override fun migrate(db: SupportSQLiteDatabase) {
    db.execSQL(
      """
      CREATE TABLE IF NOT EXISTS hybrid_media_index (
        identity TEXT NOT NULL,
        sourceType TEXT NOT NULL,
        sourceRoot TEXT NOT NULL,
        location TEXT NOT NULL,
        parentIdentity TEXT NOT NULL,
        parentDisplayName TEXT NOT NULL,
        displayName TEXT NOT NULL,
        mimeType TEXT NOT NULL,
        size INTEGER NOT NULL,
        dateModified INTEGER NOT NULL,
        isAudio INTEGER NOT NULL,
        isNoMedia INTEGER NOT NULL,
        duration INTEGER NOT NULL,
        width INTEGER NOT NULL,
        height INTEGER NOT NULL,
        rotation INTEGER NOT NULL,
        metadataState TEXT NOT NULL,
        available INTEGER NOT NULL,
        lastSeenGeneration INTEGER NOT NULL,
        PRIMARY KEY(identity)
      )
      """.trimIndent(),
    )
    db.execSQL("CREATE INDEX IF NOT EXISTS index_hybrid_media_index_parentIdentity ON hybrid_media_index(parentIdentity)")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_hybrid_media_index_sourceRoot ON hybrid_media_index(sourceRoot)")
    db.execSQL("CREATE INDEX IF NOT EXISTS index_hybrid_media_index_available ON hybrid_media_index(available)")
    db.execSQL(
      """
      CREATE TABLE IF NOT EXISTS hybrid_media_roots (
        identity TEXT NOT NULL,
        sourceType TEXT NOT NULL,
        location TEXT NOT NULL,
        displayName TEXT NOT NULL,
        available INTEGER NOT NULL,
        lastGeneration INTEGER NOT NULL,
        lastCompletedAt INTEGER NOT NULL,
        lastError TEXT,
        PRIMARY KEY(identity)
      )
      """.trimIndent(),
    )
  }
}

val MIGRATION_15_16 = object : Migration(15, 16) {
  override fun migrate(db: SupportSQLiteDatabase) {
    db.execSQL("ALTER TABLE `PlaybackStateEntity` ADD COLUMN `videoAspect` TEXT")
    db.execSQL("ALTER TABLE `PlaybackStateEntity` ADD COLUMN `customAspectRatio` REAL NOT NULL DEFAULT -1.0")
  }
}

val MIGRATION_16_17 = object : Migration(16, 17) {
  override fun migrate(db: SupportSQLiteDatabase) {
    db.execSQL("ALTER TABLE `PlaylistEntity` ADD COLUMN `customThumbnailPath` TEXT")
  }
}

val MIGRATION_17_18 = object : Migration(17, 18) {
  override fun migrate(db: SupportSQLiteDatabase) {
    db.execSQL(
      """
      CREATE TABLE IF NOT EXISTS `media_play_counts` (
        `filePath` TEXT NOT NULL,
        `playCount` INTEGER NOT NULL DEFAULT 1,
        `lastPlayedAt` INTEGER NOT NULL,
        PRIMARY KEY(`filePath`)
      )
      """.trimIndent(),
    )
  }
}

val MIGRATION_18_19 = object : Migration(18, 19) {
  override fun migrate(db: SupportSQLiteDatabase) {
    db.execSQL(
      """
      CREATE TABLE IF NOT EXISTS `media_bookmarks` (
        `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
        `mediaKey` TEXT NOT NULL,
        `positionMs` INTEGER NOT NULL,
        `title` TEXT NOT NULL,
        `createdAt` INTEGER NOT NULL
      )
      """.trimIndent(),
    )
    db.execSQL(
      "CREATE UNIQUE INDEX IF NOT EXISTS `index_media_bookmarks_mediaKey_positionMs` ON `media_bookmarks` (`mediaKey`, `positionMs`)",
    )
  }
}

val MIGRATION_19_20 = object : Migration(19, 20) {
  override fun migrate(db: SupportSQLiteDatabase) {
    db.execSQL(
      """
      CREATE TABLE IF NOT EXISTS `folder_aggregates` (
        `path` TEXT NOT NULL,
        `parentPath` TEXT NOT NULL,
        `name` TEXT NOT NULL,
        `lastModified` INTEGER NOT NULL,
        `directVideoCount` INTEGER NOT NULL,
        `directAudioCount` INTEGER NOT NULL,
        `directNewCount` INTEGER NOT NULL,
        `directUnwatchedCount` INTEGER NOT NULL,
        `directVideoSize` INTEGER NOT NULL,
        `directAudioSize` INTEGER NOT NULL,
        `directVideoDuration` INTEGER NOT NULL,
        `directAudioDuration` INTEGER NOT NULL,
        `fromFileSystem` INTEGER NOT NULL,
        `indexedGeneration` INTEGER NOT NULL,
        `isAnchor` INTEGER NOT NULL,
        PRIMARY KEY(`path`)
      )
      """.trimIndent(),
    )
    db.execSQL(
      "CREATE INDEX IF NOT EXISTS `index_folder_aggregates_parentPath` ON `folder_aggregates` (`parentPath`)",
    )
  }
}

val DatabaseModule =
  module {
    single<Json> {
      Json {
        isLenient = true
        ignoreUnknownKeys = true
      }
    }

    single<MpvExDatabase> {
      val context = androidContext()
      Room
        .databaseBuilder(context, MpvExDatabase::class.java, "mpvex.db")
        .setJournalMode(RoomDatabase.JournalMode.WRITE_AHEAD_LOGGING)
        .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6, MIGRATION_6_7, MIGRATION_7_8, MIGRATION_8_9, MIGRATION_9_10, MIGRATION_10_11, MIGRATION_11_12, MIGRATION_12_13, MIGRATION_13_14, MIGRATION_14_15, MIGRATION_15_16, MIGRATION_16_17, MIGRATION_17_18, MIGRATION_18_19, MIGRATION_19_20)
        .fallbackToDestructiveMigration(false) // This is now safe
        .build()
    }

    singleOf(::PlaybackStateRepositoryImpl).bind(PlaybackStateRepository::class)

    single { FolderAggregateRepository(get<MpvExDatabase>().folderAggregateDao()) }.bind(FolderAggregateSource::class)
    single { MediaTreeStore(androidContext(), get()) }

    single {
      BookmarkRepositoryImpl(get<MpvExDatabase>().bookmarkDao())
    }.bind(BookmarkRepository::class)

    single<RecentlyPlayedRepository> {
      RecentlyPlayedRepositoryImpl(get<MpvExDatabase>().recentlyPlayedDao())
    }

    single { ThumbnailRepository(androidContext()) }

    single {
      xyz.mpv.rex.database.repository.VideoMetadataCacheRepository(
        context = androidContext(),
        dao = get<MpvExDatabase>().videoMetadataDao(),
      )
    }

    single {
      xyz.mpv.rex.database.repository.HybridMediaIndexRepository(
        context = androidContext(),
        dao = get<MpvExDatabase>().hybridMediaDao(),
        browserPreferences = get(),
        foldersPreferences = get(),
        metadataCacheRepository = get(),
      )
    }

    // MediaFileRepository is a singleton object - no DI needed

    single {
      get<MpvExDatabase>().networkConnectionDao()
    }

    single {
      get<MpvExDatabase>().shortsMediaDao()
    }

    single {
      xyz.mpv.rex.repository.NetworkRepository(
        dao = get(),
      )
    }

    single {
      PlaylistRepository(
        playlistDao = get<MpvExDatabase>().playlistDao(),
      )
    }

    single {
      get<MpvExDatabase>().mediaPlayCountDao()
    }

    singleOf(::MediaPlayCountRepository)
  }
